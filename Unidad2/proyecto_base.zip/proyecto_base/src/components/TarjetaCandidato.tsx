// RETO 2 · Componente TarjetaCandidato
// Ahora muestra datos fijos y el botón no hace nada. Hay que hacerlo configurable mediante props.

export function TarjetaCandidato() {
  return (
    <article className="tarjeta">
      <h3>
        Nombre del candidato <span className="numero">Nº 0</span>
      </h3>
      <p>
        Votos: <strong>0</strong>
      </p>
      <button>Votar</button>
    </article>
  );
}
