// RETO 1 · Tipos
// Escribe aquí los tipos `Candidato` y `Estado` (consulta el enunciado).

export {};
